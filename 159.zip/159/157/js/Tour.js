AFRAME.registerComponent("tour", {
  init: function () {
    this.placesContainer = this.el;
    this.createCards()  
  },

  createCards: function () {
    const thumbNailsRef = [
      {
        id: "Avengers",
        title: "Avengers",
        url: "./assets/thumbnails/avengers50_infinitysaga_variant.jpg",
      },
      {
        id: "Batman and Robin",
        title: "Batman and Robin",
        url: "./assets/thumbnails/919JVSGvKhL._AC_UF1000,1000_QL80_.jpg",
      },

      {
        id: "Spiderman",
        title: "Spiderman",
        url: "./assets/thumbnails/clean.jpg",
      },
      {
        id: "Justice League",
        title: "Justice League",
        url: "./assets/thumbnails/IMG_3933.jpg",
      },
    ];
    let prevoiusXPosition = -60;

    for (var item of thumbNailsRef) {
      const posX = prevoiusXPosition + 25;
      const posY = 10;
      const posZ = -40;
      const position = { x: posX, y: posY, z: posZ };
      prevoiusXPosition = posX;

      // Border Element
       const borderEl = this.createBorder(position, item.id)
      // Thumbnail Element
       const Thumbnail = this.createThumbNail(item)
       borderEl.appendChild(Thumbnail)
      // Title Text Element
       const titleEl = this.createTitleEl(position, item)
       borderEl.appendChild(titleEl)
      this.placesContainer.appendChild(borderEl);
    }
  },
    createBorder:function(position,id){
      const entityEl = document.createElement("a-entity")
      entityEl.setAttribute("id", id)
      entityEl.setAttribute("visible", true)
      entityEl.setAttribute("geometry", { primitive: "plane", width: 18, height: 26, });
      entityEl.setAttribute("position", position)
      entityEl.setAttribute("material", {color: "#000000", opacity: 1})
      entityEl.setAttribute("cursor-listener", {});
      return entityEl
    },
    
    createThumbNail: function (item) { 
      const entityEl = document.createElement("a-entity"); 
      entityEl.setAttribute("visible", true); 
      entityEl.setAttribute("geometry", { primitive: "plane", width: 18, height: 26, }); 
      entityEl.setAttribute("material", { src: item.url }); 
      return entityEl; 
    },

    createTitleEl: function (position, item) { 
      const entityEl = document.createElement("a-entity"); 
      entityEl.setAttribute("text", { font: "exo2bold", align: "center", width: 70, color: "#e65100", value: item.title, }); 
      const elPosition = position; 
      elPosition.y = -20; 
      entityEl.setAttribute("position", elPosition); 
      entityEl.setAttribute("visible", true); 
      return entityEl; },
});
